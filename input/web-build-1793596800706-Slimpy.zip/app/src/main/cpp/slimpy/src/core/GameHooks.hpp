#pragma once

namespace slimpy::core::gamehooks {

bool install();
void uninstall();
void* clientInstance();

}
