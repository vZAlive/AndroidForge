#include "thirdpersonnametag.hpp"
#include <slimpy/memory/Signatures.hpp>
#include <slimpy/sdk/Memory.hpp>
#include <slimpy/sdk/Offsets.hpp>

ThirdPersonNametagModule::ThirdPersonNametagModule() : Module("Third Person Nametag", "Shows your own nametag in third person view.") {
    m_patched = false;
    m_patchTarget = nullptr;
}

ThirdPersonNametagModule::~ThirdPersonNametagModule() {
    removePatch();
}

void ThirdPersonNametagModule::onInit() {
    if (m_patchTarget) return;
    uintptr_t addr = slimpy::memory::resolve(slimpy::memory::SignatureId::NameTagThirdPersonPatch);
    if (addr != 0) {
        
        m_patchTarget = (void*)(addr);
        memcpy(m_originalBytes, m_patchTarget, 4);
    }
}

void ThirdPersonNametagModule::applyPatch() {
    if (m_patched || !m_patchTarget) return;
    uint32_t nop = 0xD503201F; 
    slimpy::sdk::patchMemory(m_patchTarget, &nop, 4);
    m_patched = true;
}

void ThirdPersonNametagModule::removePatch() {
    if (!m_patched || !m_patchTarget) return;
    slimpy::sdk::patchMemory(m_patchTarget, m_originalBytes, 4);
    m_patched = false;
}

void ThirdPersonNametagModule::onEnable() {
    applyPatch();
}

void ThirdPersonNametagModule::onDisable() {
    removePatch();
}

