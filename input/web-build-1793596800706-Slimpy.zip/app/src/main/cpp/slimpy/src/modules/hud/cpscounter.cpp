#include "cpscounter.hpp"
#include <mutex>

namespace {
constexpr int kMouseLeft = 1;
constexpr int kMouseRight = 2;
constexpr auto kWindow = std::chrono::seconds(1);
}

void CpsCounterModule::Ring::push(Clock::time_point t) {
    stamps[head] = t;
    head = (head + 1) % kCapacity;
    if (count < kCapacity) ++count;
}

int CpsCounterModule::Ring::countWithin(Clock::time_point now) {
    int n = 0;
    for (int i = 0; i < count; ++i) {
        const int idx = (head - 1 - i + kCapacity) % kCapacity;
        if (now - stamps[idx] <= kWindow) ++n;
        else break; // newest -> oldest, so the rest are older
    }
    count = n; // drop expired entries
    return n;
}

CpsCounterModule::CpsCounterModule()
    : Module("CPS Counter", "Shows left and right clicks per second.") {
    m_style.posY = 60.0f;
}

void CpsCounterModule::onEnable() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_left.clear();
    m_right.clear();
    m_lastL = m_lastR = -1;
}

bool CpsCounterModule::onMouseEvent(int button, bool isDown) {
    if (!isDown || !enabled) return false;
    if (button != kMouseLeft && button != kMouseRight) return false;
    const auto now = Clock::now();
    std::lock_guard<std::mutex> lock(m_mutex);
    (button == kMouseLeft ? m_left : m_right).push(now);
    return false; // observe only
}

void CpsCounterModule::onFrame() {
    int l, r;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        const auto now = Clock::now();
        l = m_left.countWithin(now);
        r = m_right.countWithin(now);
    }
    if (l != m_lastL || r != m_lastR || m_text.empty()) {
        m_lastL = l;
        m_lastR = r;
        m_text.clear();
        if (m_showLeft) m_text += "L " + std::to_string(l);
        if (m_showLeft && m_showRight) m_text += " | ";
        if (m_showRight) m_text += "R " + std::to_string(r);
        if (m_text.empty()) m_text = "CPS";
    }
    slimpy::hud::submit(moduleId, m_style, m_text);
}

void CpsCounterModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    m_style.load(j);
    m_showLeft = j.value("m_showLeft", m_showLeft);
    m_showRight = j.value("m_showRight", m_showRight);
    m_lastL = m_lastR = -1;
    m_text.clear();
}

void CpsCounterModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    m_style.save(j);
    j["m_showLeft"] = m_showLeft;
    j["m_showRight"] = m_showRight;
}
