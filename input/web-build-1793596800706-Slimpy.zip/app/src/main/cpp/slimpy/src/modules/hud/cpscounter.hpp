#pragma once
#include "../Module.hpp"
#include "hudtext.hpp"
#include <array>
#include <chrono>
#include <mutex>

// Tracks physical left/right clicks. Never consumes input.
class CpsCounterModule : public Module {
public:
    CpsCounterModule();
    void onEnable() override;
    bool onMouseEvent(int button, bool isDown) override;
    void onFrame() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

private:
    using Clock = std::chrono::steady_clock;
    // Fixed ring buffer: no allocation on the input path.
    struct Ring {
        static constexpr int kCapacity = 64;
        std::array<Clock::time_point, kCapacity> stamps{};
        int head = 0;
        int count = 0;
        void push(Clock::time_point t);
        int countWithin(Clock::time_point now);
        void clear() { head = 0; count = 0; }
    };

    slimpy::hud::Style m_style;
    Ring m_left, m_right;
    std::mutex m_mutex;
    bool m_showLeft = true;
    bool m_showRight = true;
    int m_lastL = -1, m_lastR = -1;
    std::string m_text;
};
