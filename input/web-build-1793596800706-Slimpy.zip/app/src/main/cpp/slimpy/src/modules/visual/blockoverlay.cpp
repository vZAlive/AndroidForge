#include "blockoverlay.hpp"
#include "core/RenderState.hpp"
#include "core/memory/Hooks.hpp"
#include "modules/hud/hudtext.hpp"
#include <slimpy/events/EventBus.hpp>
#include <slimpy/events/LocalPlayerTickEvent.hpp>
#include <slimpy/memory/Signatures.hpp>
#include <slimpy/sdk/Offsets.hpp>
#include <slimpy/sdk/Types.hpp>
#include <cmath>
#include <cstring>
#include <string>

namespace {

using namespace slimpy;

using TessBeginFn = void (*)(void*, void*, int, int, int);
using TessColorFn = void (*)(void*, float, float, float, float);
using TessVertexFn = void (*)(void*, float, float, float);
using RenderMeshFn = void (*)(void*, void*, void*, char*);
using GetHitResultFn = void* (*)(void*);

// Minimal stand-in for the engine's MaterialPtr (two words, never freed here).
struct MaterialPtr {
    void* data[2]{nullptr, nullptr};
    explicit operator bool() const { return data[0] != nullptr; }
};

struct HashedString {
    std::uint64_t hash = 0;
    std::string str;
    mutable const HashedString* lastMatch = nullptr;
    explicit HashedString(const char* s) : str(s ? s : "") {
        constexpr std::uint64_t kOffset = 0xCBF29CE484222325ULL, kPrime = 0x100000001B3ULL;
        if (!str.empty()) {
            hash = kOffset;
            for (char ch : str) hash = static_cast<std::uint64_t>(static_cast<unsigned char>(ch)) ^ (kPrime * hash);
        }
    }
};

BlockOverlayModule* g_mod = nullptr;
TessBeginFn g_begin = nullptr;
TessColorFn g_color = nullptr;
TessVertexFn g_vertex = nullptr;
RenderMeshFn g_renderMesh = nullptr;
GetHitResultFn g_getHit = nullptr;
std::uintptr_t g_materialGroup = 0;
MaterialPtr g_material;
void* g_player = nullptr;
void (*g_renderLevelOrig)(void*, void*, void*) = nullptr;

// Finds the ADRP+ADD pair that materialises a global's address (arm64).
std::uintptr_t resolveAdrp(std::uint32_t* insns, std::size_t count, std::uint32_t reg) {
    for (std::size_t i = 0; i < count; i++) {
        const std::uint32_t insn = insns[i];
        if ((insn & 0x1F) != reg) continue;
        if ((insn & 0x9F000000) == 0x90000000) {
            const std::uintptr_t page = (reinterpret_cast<std::uintptr_t>(&insns[i]) & ~0xFFFULL)
                + ((std::int64_t)((std::uint64_t)((insn >> 3) & 0x1FFFFC | (insn >> 29) & 3) << 43) >> 31);
            for (std::size_t j = i + 1; j < count; j++) {
                const std::uint32_t add = insns[j];
                if ((add & 0xFF000000) == 0x91000000 && ((add >> 5) & 0x1F) == reg && (add & 0x1F) == reg) {
                    std::uint32_t imm12 = (add >> 10) & 0xFFF;
                    if (add & 0x400000) imm12 <<= 12;
                    return page + imm12;
                }
                if ((add & 0x1F) == reg) break;
            }
        }
    }
    return 0;
}

void ensureMaterial() {
    if (g_material || !g_materialGroup) return;
    HashedString name("selection_box");
    void** vtable = *reinterpret_cast<void***>(g_materialGroup);
    if (!vtable || !vtable[2]) return;
    using GetMat = MaterialPtr (*)(void*, const HashedString*);
    g_material = reinterpret_cast<GetMat>(vtable[2])(reinterpret_cast<void*>(g_materialGroup), &name);
}

// Resolves the targeted block's min corner. Uses the engine's BlockPos when it
// agrees with the hit point; otherwise falls back to nudging the hit point along
// the ray so it lands inside the block.
bool targetedBlock(void* hit, float& bx, float& by, float& bz) {
    const auto base = reinterpret_cast<std::uintptr_t>(hit);
    if (*reinterpret_cast<int*>(base + sdk::offsets::HitResult::mType) != 0) return false; // 0 == tile
    const auto start = *reinterpret_cast<sdk::Vec3*>(base + sdk::offsets::HitResult::mStartPos);
    const auto pos = *reinterpret_cast<sdk::Vec3*>(base + sdk::offsets::HitResult::mPos);
    if (!std::isfinite(pos.x) || !std::isfinite(pos.y) || !std::isfinite(pos.z)) return false;

    const int* bp = reinterpret_cast<int*>(base + sdk::offsets::HitResult::mBlock);
    constexpr float kTol = 0.02f;
    if (pos.x >= bp[0] - kTol && pos.x <= bp[0] + 1 + kTol &&
        pos.y >= bp[1] - kTol && pos.y <= bp[1] + 1 + kTol &&
        pos.z >= bp[2] - kTol && pos.z <= bp[2] + 1 + kTol) {
        bx = static_cast<float>(bp[0]); by = static_cast<float>(bp[1]); bz = static_cast<float>(bp[2]);
        return true;
    }
    float dx = pos.x - start.x, dy = pos.y - start.y, dz = pos.z - start.z;
    const float len = std::sqrt(dx * dx + dy * dy + dz * dz);
    if (len < 1e-4f) return false;
    const float k = 0.01f / len;
    bx = std::floor(pos.x + dx * k); by = std::floor(pos.y + dy * k); bz = std::floor(pos.z + dz * k);
    return true;
}

void renderLevelHook(void* self, void* screenContext, void* a3) {
    if (g_renderLevelOrig) g_renderLevelOrig(self, screenContext, a3);

    if (!g_mod || !g_mod->enabled || !g_player) return;
    if (!g_begin || !g_color || !g_vertex || !g_renderMesh || !g_getHit) return;
    if (!screenContext || reinterpret_cast<std::uintptr_t>(screenContext) < 0x1000) return;

    void* level = *reinterpret_cast<void**>(reinterpret_cast<std::uintptr_t>(g_player) + sdk::offsets::Actor::mLevel);
    if (!level) return;
    void* hit = g_getHit(level);
    if (!hit) return;
    float bx, by, bz;
    if (!targetedBlock(hit, bx, by, bz)) return;

    const auto tessAddr = *reinterpret_cast<std::uintptr_t*>(
        reinterpret_cast<std::uintptr_t>(screenContext) + sdk::offsets::ScreenContext::mTessellator);
    if (tessAddr < 0x1000) return;
    void* tess = reinterpret_cast<void*>(tessAddr);

    const auto lrp = *reinterpret_cast<std::uintptr_t*>(
        reinterpret_cast<std::uintptr_t>(self) + sdk::offsets::LevelRenderer::mLevelRendererPlayer);
    if (lrp < 0x1000) return;
    const float* cam = reinterpret_cast<float*>(lrp + sdk::offsets::LevelRendererPlayer::mCamPos);

    ensureMaterial();
    void* material = g_material ? static_cast<void*>(&g_material)
                                : reinterpret_cast<void*>(lrp + sdk::offsets::LevelRendererPlayer::mSelectionOverlayMaterial);

    core::ScopedShaderColor shaderColor(screenContext);
    if (!shaderColor) return;

    // Slightly inflated so the lines don't z-fight with the block faces.
    constexpr float e = 0.002f;
    const float x0 = bx - e - cam[0], x1 = bx + 1 + e - cam[0];
    const float y0 = by - e - cam[1], y1 = by + 1 + e - cam[1];
    const float z0 = bz - e - cam[2], z1 = bz + 1 + e - cam[2];
    const float c[8][3] = {{x0,y0,z0},{x1,y0,z0},{x1,y0,z1},{x0,y0,z1},{x0,y1,z0},{x1,y1,z0},{x1,y1,z1},{x0,y1,z1}};
    static constexpr int kEdges[12][2] = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};

    const std::uint32_t col = g_mod->lineColor;
    g_begin(tess, nullptr, 4, 24, 0);
    g_color(tess, ((col >> 16) & 0xFF) / 255.0f, ((col >> 8) & 0xFF) / 255.0f, (col & 0xFF) / 255.0f, ((col >> 24) & 0xFF) / 255.0f);
    for (const auto& edge : kEdges) {
        g_vertex(tess, c[edge[0]][0], c[edge[0]][1], c[edge[0]][2]);
        g_vertex(tess, c[edge[1]][0], c[edge[1]][1], c[edge[1]][2]);
    }
    char pad[0x58];
    std::memset(pad, 0, sizeof(pad));
    g_renderMesh(screenContext, tess, material, pad);
}

} // namespace

BlockOverlayModule::BlockOverlayModule()
    : Module("Block Overlay", "Outlines the block you are looking at.") {
    g_mod = this;
}

BlockOverlayModule::~BlockOverlayModule() {
    if (g_mod == this) g_mod = nullptr;
}

void BlockOverlayModule::onInit() {
    using namespace slimpy::memory;
    m_patchTarget = reinterpret_cast<void*>(resolve(SignatureId::RenderLevel));
    g_begin = reinterpret_cast<TessBeginFn>(resolve(SignatureId::TessellatorBegin));
    g_color = reinterpret_cast<TessColorFn>(resolve(SignatureId::TessellatorColor));
    g_vertex = reinterpret_cast<TessVertexFn>(resolve(SignatureId::TessellatorVertex));
    g_renderMesh = reinterpret_cast<RenderMeshFn>(resolve(SignatureId::MeshHelpersRenderMeshImmediately2));
    g_getHit = reinterpret_cast<GetHitResultFn>(resolve(SignatureId::LevelGetHitResult));
    if (const auto group = resolve(SignatureId::RenderMaterialGroupCommon)) {
        const auto addr = resolveAdrp(reinterpret_cast<std::uint32_t*>(group), 2, 0);
        if (addr) g_materialGroup = addr + sdk::offsets::MaterialGroup::mRenderMaterialGroupOffset;
    }
    events::bus().subscribe<events::LocalPlayerTickEvent>([](auto& event) {
        if (g_mod && g_mod->enabled) g_player = event.player;
    });
}

void BlockOverlayModule::onEnable() {
    if (m_patched || !m_patchTarget) return;
    hooks::install(m_patchTarget, reinterpret_cast<void*>(renderLevelHook), reinterpret_cast<void**>(&g_renderLevelOrig));
    m_patched = true;
}

void BlockOverlayModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    if (j.contains("m_lineColor") && j["m_lineColor"].is_string())
        slimpy::hud::parseColor(j["m_lineColor"].get<std::string>(), lineColor);
}

void BlockOverlayModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["m_lineColor"] = slimpy::hud::formatColor(lineColor);
}
