#pragma once

#include <slimpy/sdk/Memory.hpp>
#include <slimpy/sdk/Offsets.hpp>
#include <slimpy/sdk/world/HitResult.hpp>

namespace slimpy::sdk {

class Level {
public:
    void* actorManager() const { return field<void*>(this, offsets::Level::mActorManager); }

    HitResult* storedHitResult() {
        auto* wrapper = field<void*>(this, offsets::Level::mHitResultWrapper);
        if (!wrapper) return nullptr;
        return reinterpret_cast<HitResult*>(reinterpret_cast<std::uintptr_t>(wrapper) + offsets::HitResultWrapper::mHitResult);
    }

    const HitResult* storedHitResult() const {
        auto* wrapper = field<const void*>(this, offsets::Level::mHitResultWrapper);
        if (!wrapper) return nullptr;
        return reinterpret_cast<const HitResult*>(reinterpret_cast<std::uintptr_t>(wrapper) + offsets::HitResultWrapper::mHitResult);
    }
};

}
