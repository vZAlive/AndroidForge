#pragma once

#include <slimpy/sdk/Memory.hpp>
#include <slimpy/sdk/Offsets.hpp>
#include <slimpy/sdk/Types.hpp>

namespace slimpy::sdk {

class HitResult {
public:
    int type() const { return field<int>(this, offsets::HitResult::mType); }
    const Vec3& startPosition() const { return field<Vec3>(this, offsets::HitResult::mStartPos); }
    const Vec3& position() const { return field<Vec3>(this, offsets::HitResult::mPos); }
};

}
