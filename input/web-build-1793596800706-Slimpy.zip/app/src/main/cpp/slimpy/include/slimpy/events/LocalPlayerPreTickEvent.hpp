#pragma once

#include <slimpy/events/Event.hpp>

namespace slimpy::sdk { class Player; }

namespace slimpy::events {

struct LocalPlayerPreTickEvent {
    static constexpr EventType type = EventType::LocalPlayerPreTick;
    sdk::Player* player;
};

}
