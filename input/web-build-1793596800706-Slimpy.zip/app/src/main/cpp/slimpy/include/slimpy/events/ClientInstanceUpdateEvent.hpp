#pragma once

#include <slimpy/events/Event.hpp>

namespace slimpy::sdk { class ClientInstance; }

namespace slimpy::events {

struct ClientInstanceUpdateEvent {
    static constexpr EventType type = EventType::ClientInstanceUpdate;
    sdk::ClientInstance* clientInstance;
};

}
