#pragma once

#include <slimpy/events/Event.hpp>

namespace slimpy::events {

struct FrameEvent {
    static constexpr EventType type = EventType::Frame;
};

}
