#pragma once

#include <slimpy/sdk/offsets/Core.hpp>
#include <slimpy/sdk/offsets/World.hpp>
#include <slimpy/sdk/offsets/Render.hpp>
#include <slimpy/sdk/offsets/Network.hpp>
#include <slimpy/sdk/offsets/Skin.hpp>
#include <slimpy/sdk/offsets/UI.hpp>

#include <slimpy/sdk/offsets/Inventory.hpp>
