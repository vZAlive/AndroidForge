#pragma once

#include <slimpy/sdk/Memory.hpp>
#include <slimpy/sdk/Offsets.hpp>
#include <slimpy/sdk/render/LevelRendererPlayer.hpp>

namespace slimpy::sdk {

class LevelRenderer {
public:
    void* renderChunkCoordinatorTable() {
        return reinterpret_cast<void*>(reinterpret_cast<std::uintptr_t>(this) + offsets::LevelRenderer::mRenderChunkCoordinators);
    }

    LevelRendererPlayer* playerRenderer() { return field<LevelRendererPlayer*>(this, offsets::LevelRenderer::mLevelRendererPlayer); }
};

}
