#include "ModuleRegistry.hpp"
#include "visual/motionblur.hpp"
#include "visual/viewmodel.hpp"
#include "visual/thirdpersonnametag.hpp"
#include "visual/fpsunlocker.hpp"
#include "visual/blockoverlay.hpp"
#include "visual/hitbox.hpp"
#include "visual/swingmodifier.hpp"
#include "visual/zoom.hpp"
#include "player/autosprint.hpp"
#include "visual/fullbright.hpp"
#include "hud/tablist.hpp"
#include "hud/fpscounter.hpp"
#include "hud/cpscounter.hpp"

ModuleRegistry& ModuleRegistry::get() {
    static ModuleRegistry registry;
    return registry;
}

Module* ModuleRegistry::find(std::string_view id) const {
    const auto it = mById.find(id);
    return it == mById.end() ? nullptr : it->second;
}

const std::vector<Module*>& ModuleRegistry::modules() const {
    return mView;
}

void ModuleRegistry::initialize() {
    if (mInitialized) return;
    for (auto* module : mView) module->onInit();
    mInitialized = true;
}

void ModuleRegistry::onFrame() {
    for (auto* module : mView) if (module->enabled) module->onFrame();
}

bool ModuleRegistry::onMouseEvent(int button, bool isDown) {
    bool consumed = false;
    for (auto* module : mView) if (module->onMouseEvent(button, isDown)) consumed = true;
    return consumed;
}

void ModuleRegistry::setKeybindBlocked(bool blocked) {
    mKeybindBlocked = blocked;
}

bool ModuleRegistry::keybindBlocked() const {
    return mKeybindBlocked;
}

void registerAllModules() {
    auto& registry = ModuleRegistry::get();
    if (!registry.modules().empty()) return;
    registry.emplace<MotionBlurModule>();
    registry.emplace<BlockOverlayModule>();
    registry.emplace<HitboxModule>();
    registry.emplace<ViewModelModule>();
    registry.emplace<SwingModifierModule>();
    registry.emplace<ZoomModule>();
    registry.emplace<AutoSprintModule>();
    registry.emplace<FullbrightModule>();
    registry.emplace<TablistModule>();
    registry.emplace<ThirdPersonNametagModule>();
    registry.emplace<FpsCounterModule>();
    registry.emplace<CpsCounterModule>();
    registry.emplace<FPSUnlockerModule>();
}
