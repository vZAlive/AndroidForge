#include "fpsunlocker.hpp"
#include <EGL/egl.h>
#include <time.h>
#include <errno.h>
#include <algorithm>
#include <cstdlib>
#include <pl/ModMenu.hpp>
#include <pl/ModMenuConfig.hpp>

FPSUnlockerModule::FPSUnlockerModule()
    : Module("Unlock FPS", "Disables VSync and optionally caps the frame rate (Unlimited, 30, 60, 90, 120, 144 or 165). The display or driver may still limit it.") {}

void FPSUnlockerModule::onInit() {}

void FPSUnlockerModule::onEnable() {
    m_appliedDisplay = EGL_NO_DISPLAY;
    m_appliedSurface = EGL_NO_SURFACE;
    m_hasLastFrame = false;
}

void FPSUnlockerModule::onDisable() {
    EGLDisplay display = eglGetCurrentDisplay();
    if (display != EGL_NO_DISPLAY) {
        eglSwapInterval(display, 1);
    }
    m_appliedDisplay = EGL_NO_DISPLAY;
    m_appliedSurface = EGL_NO_SURFACE;
    m_hasLastFrame = false;
}

void FPSUnlockerModule::onFrame() {
    EGLDisplay display = eglGetCurrentDisplay();
    EGLSurface surface = eglGetCurrentSurface(EGL_DRAW);
    if (display != EGL_NO_DISPLAY && surface != EGL_NO_SURFACE &&
        (display != m_appliedDisplay || surface != m_appliedSurface)) {
        if (eglSwapInterval(display, 0) == EGL_TRUE) {
            m_appliedDisplay = display;
            m_appliedSurface = surface;
        }
    }

    const int targetFPS = kPresets[std::clamp(m_preset.load(std::memory_order_relaxed), 0, kPresetCount - 1)];
    if (targetFPS <= 0) {
        m_hasLastFrame = false;
        return;
    }

    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);

    if (m_hasLastFrame) {
        long long frameDurationNs = 1000000000LL / targetFPS;

        struct timespec deadline;
        deadline.tv_sec = m_lastFrameTime.tv_sec;
        deadline.tv_nsec = m_lastFrameTime.tv_nsec + frameDurationNs;

        while (deadline.tv_nsec >= 1000000000L) {
            deadline.tv_sec++;
            deadline.tv_nsec -= 1000000000L;
        }

        while (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &deadline, nullptr) == EINTR) {
        }

        m_lastFrameTime = deadline;
    } else {
        m_lastFrameTime = now;
        m_hasLastFrame = true;
    }
}

int FPSUnlockerModule::presetForFps(int fps) {
    int best = 0;
    for (int i = 0; i < kPresetCount; ++i) {
        if (std::abs(kPresets[i] - fps) < std::abs(kPresets[best] - fps)) best = i;
    }
    return fps <= 0 ? 0 : best;
}

void FPSUnlockerModule::onMenuRegistered() {
    using namespace pl::modmenu;
    ConfigSchemaBuilder schema;
    schema.defaultCategory("limit")
        .category("limit", "Frame Rate", "Choose a frame cap or unlock completely");
    ConfigNodeV2 node;
    node.id = "fpsPreset";
    node.key = "fpsPreset";
    node.title = "FPS Limit Preset";
    node.description = "0 = Unlimited, 1 = 30, 2 = 60, 3 = 90, 4 = 120, 5 = 144, 6 = 165 FPS. "
                       "The display or driver may still limit the real frame rate.";
    node.category = "limit";
    node.type = ConfigControlTypeV2::SliderInt;
    node.minValue = "0";
    node.maxValue = "6";
    node.step = "1";
    schema.node(std::move(node));
    pl::modmenu::setConfigSchemaJson(moduleId, schema.toJson());
}

void FPSUnlockerModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    if (j.contains("fpsPreset") && j["fpsPreset"].is_number_integer()) {
        m_preset.store(std::clamp(j["fpsPreset"].get<int>(), 0, kPresetCount - 1));
    } else if (j.contains("targetFPS") && j["targetFPS"].is_number_integer()) {
        // Migrate configs saved before presets existed.
        m_preset.store(presetForFps(j["targetFPS"].get<int>()));
    }
}

void FPSUnlockerModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["fpsPreset"] = m_preset.load();
}
