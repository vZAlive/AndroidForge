#include "autosprint.hpp"
#include <slimpy/events/EventBus.hpp>
#include <slimpy/sdk/input/MoveInput.hpp>

AutoSprintModule::AutoSprintModule()
    : Module("AutoSprint", "Holds Minecraft's native sprint input for you.") {}

void AutoSprintModule::onInit() {
    slimpy::events::bus().subscribe<slimpy::events::LocalPlayerPreTickEvent>([this](auto& event) {
        if (!enabled || !event.player) return;
        auto* input = slimpy::sdk::moveInputComponent(event.player);
        if (!input) return;
        input->mRawInputState.set(MoveInputState::Flag::SprintDown, true);
    }, slimpy::events::EventPriority::First);
}
