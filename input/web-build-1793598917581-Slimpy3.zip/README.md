# Slimpy

Minimal MCPE (Minecraft Bedrock, Android, arm64-v8a) performance client.
Six features only: **Motion Blur, Block Overlay, FPS Counter (+ Unlock FPS), CPS Counter, View Model, Third-Person Nametag.**

Open this folder in Android Studio (Ladybug or newer, JDK 17, NDK 28.2.13676358).

## STATUS — stage 1 (read this first)

| Part | State |
|---|---|
| Native mod `libSlimpy.so` (`app/src/main/cpp/slimpy`) | **Written, never compiled.** 7 modules, 50 -> 7 trimmed. |
| App identity | applicationId `com.slimpy.client`, label "Slimpy", icon from supplied logo. |
| Launcher Java/Kotlin (221 files) | **Still the Levi code.** Not yet stripped, not yet wired to load `libSlimpy.so`. |
| Build | **Never built or run.** CI-ready packaging added; first real build will likely surface errors. |

### Building from a source ZIP (AndroidForge / CI)
The ZIP root is the Gradle project root (`settings.gradle`, `gradlew`, `app/`). It is built to work without git:
- The empty `preloader` / `libHttpClient` submodules are fetched from GitHub by CMake at configure time
  (`app/src/main/cpp/CMakeLists.txt`), tracking `main` of each repo, **not pinned** — if upstream moved, pin a commit there.
- `app/google-services.json` is a **placeholder** so the Google Services plugin doesn't fail; Firebase does nothing useful with it.
  Crashlytics mapping/symbol upload is disabled. Both go away in stage 2.
- nlohmann_json 3.11.3 and glm 1.0.1 are fetched (pinned). Needs network on the build machine.
- Needs JDK 17, Gradle 8.13 (wrapper), NDK 28.2.13676358, compileSdk 36. Pick the **debug** variant; release is unsigned.
- The AndroidForge repo itself could not be read, so its exact ZIP/workflow rules are unverified.

### Deliberate deviation: Java package is still `org.levimc.launcher`
The native preloader and the launcher bridge look up Java classes and JNI symbols by their full package name
(`Java_org_levimc_launcher_...`). The preloader source was not supplied, so renaming the Java package now would
break mod loading at runtime. Only the user-visible identity (applicationId, label, icon) is Slimpy.
A full package rename is a stage-2 task and needs the preloader source patched in the same commit.

## Layout
- `app/src/main/cpp/slimpy/` — native mod. One file per feature in `src/modules/{visual,hud}`.
  - `visual/motionblur`, `visual/viewmodel`, `visual/thirdpersonnametag`, `visual/fpsunlocker` (shown as "Unlock FPS"), `visual/blockoverlay`
  - `hud/fpscounter`, `hud/cpscounter`, `hud/hudtext.hpp` (shared HUD draw helper)
  - `src/config` persists settings to `config.json` in the mod's config dir (debounced, written off the render thread).
  - `src/core/memory/Signatures.cpp` — trimmed to the 46 signatures these modules use.
  - Upstream: BedrockTools by RadiantByte, MIT (`LICENSE-BedrockTools-MIT.txt`).
- Launcher: Levi Launchroid (Apache-2.0, `LICENSE`).

## How the features work
- **FPS Counter**: counts frames, refreshes the text twice per second. **CPS Counter**: observes mouse-down events (never consumes them) in a 64-entry ring buffer; no allocation on the input path.
- **Unlock FPS**: sets `eglSwapInterval(0)` and optionally sleeps to a target FPS (0 = uncapped). The display, driver or compositor can still cap frame rate; this only removes VSync.
- **Block Overlay**: hooks the level render, reads the engine hit result, draws 12 edges via the game tessellator. Zero work when disabled apart from one branch in the hook. The block position is read from `HitResult+32` and **checked against the hit point at runtime**, falling back to a ray nudge if they disagree. The offset is inferred from struct layout, not verified on a device.
- **Motion Blur / View Model / Third-Person Nametag**: unchanged upstream implementations (not yet re-audited or optimised).

## Game version
Signatures target the version declared by the upstream mod (Minecraft `1.26.60.X`). Not re-validated.

## Stage 2 (needs compile feedback)
Remove from the launcher: Firebase/Crashlytics/Play Games/billing, Microsoft login and account code, CurseForge, news/changelog,
world editor + `worldtools` native lib + `libinbuiltmods.so` (closed binary, hard-codes the Levi package), Levi inbuilt mods and overlays;
replace `MainActivity` with a small version-select/launch screen; load `libSlimpy.so` directly from `MinecraftRuntimePreparer`;
rewrite strings (1100 lines, many Levi), drop non-English locales, then re-run a leftover-branding scan.
